package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText x = findViewById(R.id.editTextTextPersonName3);
   final EditText y = findViewById(R.id.editTextTextPersonName4);
   Button add = findViewById(R.id.button3);
        Button MULTIPLICATION  = findViewById(R.id.button4);
        Button DIVISION   = findViewById(R.id.button5);
add.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        double A = Double.parseDouble(x.getText().toString());
        double B = Double.parseDouble(y.getText().toString());
        double Letter = A + B;
        Toast.makeText(MainActivity.this, Letter + "", Toast.LENGTH_SHORT).show();
    }
});

MULTIPLICATION.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        double A = Double.parseDouble(x.getText().toString());
        double B = Double.parseDouble(y.getText().toString());
        double Letter = A * B;
        Toast.makeText(MainActivity.this, Letter + "", Toast.LENGTH_SHORT).show();
    }
});

DIVISION.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        double A = Double.parseDouble(x.getText().toString());
        double B = Double.parseDouble(y.getText().toString());
        double Letter = A / B;
        Toast.makeText(MainActivity.this, Letter + "", Toast.LENGTH_SHORT).show();
    }
});
    }
}